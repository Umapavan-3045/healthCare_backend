package com.users.app.dto;

import lombok.Data;

@Data
public class UpdatePasswordDto {
	String oldPassword;
	String newPassword;
}
